<?php
    function dataFormatada($data){
        return date('d/m/Y',strtotime($data)); 
    }
?>